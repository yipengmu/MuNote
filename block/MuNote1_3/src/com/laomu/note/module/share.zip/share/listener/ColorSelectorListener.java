package com.laomu.note.module.share.listener;

/**
 * Created by ${yipengmu} on 16/3/9.
 */
public interface ColorSelectorListener {

    void onColorSelectorChange(int color);
}
