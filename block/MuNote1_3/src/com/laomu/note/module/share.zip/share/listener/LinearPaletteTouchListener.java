package com.laomu.note.module.share.listener;

/**
 * Created by yipengmu on 16/3/15.
 */
public interface LinearPaletteTouchListener {
    void onPaletteTouchDown();
    void onPaletteTouchUp();
}
