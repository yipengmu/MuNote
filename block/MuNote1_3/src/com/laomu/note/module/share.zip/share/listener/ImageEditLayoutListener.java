package com.laomu.note.module.share.listener;

/**
 * Created by ${yipengmu} on 16/3/10.
 */
public interface ImageEditLayoutListener {
    void onImageLayoutFinished(float width,float height);
}
