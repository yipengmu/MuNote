package com.laomu.note.module.share.type;

/**
 * Created by ${yipengmu} on 16/3/7.
 */
public enum ScreenShotModeEnum {
    MODE_TEXT,
    MODE_DOODLE
}
