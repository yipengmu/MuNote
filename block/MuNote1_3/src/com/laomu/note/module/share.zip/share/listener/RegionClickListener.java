package com.laomu.note.module.share.listener;

/**
 * Created by ${yipengmu} on 16/3/4.
 */
public interface RegionClickListener {

    void onTextRectOutSideClick();

    void onTextRectInSideClick();
}
